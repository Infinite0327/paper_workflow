"""Scripts for langchain-openrouter."""
